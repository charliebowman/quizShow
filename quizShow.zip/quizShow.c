#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

void initialise_quiz(void) {
	printf("\n\n\n\nWelcome to \"Charlie's Questionnaire\" !\n\n\n"); 
}

void question_prompt(void) {
	printf("\nPress A, B, C or D followed by enter: \n"); 
}

void display_question(int q) {
	char buffer[256];  
	FILE* question1;
	char q1;
	FILE* question2;
	char q2; 
	FILE* question3;
	char q3;
	FILE* question4;
	char q4; 
	FILE* question5; 
	char q5;
	FILE* question6;
	char q6; 
	FILE* question7;
	char q7; 
	FILE* question8;
	char q8;
	FILE* question9;
	char q9; 
	FILE* question10; 
	char q10; 

	if (q == 1) {

		question1 = fopen("question1.txt", "r"); 
		if (question1) {
			while(fgets(buffer, sizeof(buffer), question1)) {
				fputs(buffer, stdout); 
			}
			fclose(question1); 
		} else {
			/* Provide error diagnostic. */
			fprintf(stderr, "Could not open that question."); 
			perror(0); 
			errno = 0; 
		}

		question_prompt(); 
		scanf("%c", &q1); 
		if (q1 == 'B' || q1 == 'b') {
			printf("\nCongratulations you got it correct !\n\n");
			sleep(2); 
		} else {
			printf("\nThat is incorrect !\n\n"); 
			sleep(2); 
		}
		system("clear"); //unix/linux
			 	
	}

	if (q == 2) {

		question2 = fopen("question2.txt", "r"); 
		if (question2) {
			while(fgets(buffer, sizeof(buffer), question2)) {
				fputs(buffer, stdout); 
			}
			fclose(question2); 
		} else {
			/* Provide error diagnostic. */
			fprintf(stderr, "Could not open that question."); 
			perror(0); 
			errno = 0; 
		}
		question_prompt(); 
		scanf(" %c", &q2); 
		if (q2 == 'D' || q2 == 'd') {
			printf("\nCongratulations you got it correct !\n\n");
			sleep(2); 
		} else {
			printf("\nThat is incorrect !\n\n"); 
			sleep(2); 
		}
		system("clear"); //unix/linux
	}

	if (q == 3) {
		question3 = fopen("question3.txt", "r"); 
		if (question3) {
			while(fgets(buffer, 256, question3)) {
				fputs(buffer, stdout); 
			}
			fclose(question3); 
		} else {
			/* Provide error diagnostic. */
			fprintf(stderr, "Could not open that question."); 
			perror(0); 
			errno = 0; 
		}

		question_prompt(); 
		scanf(" %c", &q3); 
		if (q3 == 'C' || q3 == 'c') {
			printf("\nCongratulations you got it correct !\n\n");
			sleep(2); 
		} else {
			printf("\nThat is incorrect !\n\n"); 
			sleep(2); 
		}
		system("clear"); //unix/linux
	}

	if (q == 4) {
		question4 = fopen("question4.txt", "r"); 
		if (question4) {
			while(fgets(buffer, 256, question4)) {
				fputs(buffer, stdout); 
			}
			fclose(question4); 
		} else {
			/* Provide error diagnostic. */
			fprintf(stderr, "Could not open that question."); 
			perror(0); 
			errno = 0; 
		}

		question_prompt(); 
		scanf(" %c", &q4); 
		if (q4 == 'C' || q4 == 'c') {
			printf("\nCongratulations you got it correct !\n\n");
			sleep(2); 
		} else {
			printf("\nThat is incorrect !\n\n"); 
			sleep(2); 
		}
		system("clear"); //unix/linux
	}

	if (q == 5) {
		question5 = fopen("question5.txt", "r"); 
		if (question5) {
			while(fgets(buffer, 256, question5)) {
				fputs(buffer, stdout); 
			}
			fclose(question5); 
		} else {
			/* Provide error diagnostic. */
			fprintf(stderr, "Could not open that question."); 
			perror(0); 
			errno = 0; 
		}

		question_prompt(); 
		scanf(" %c", &q5); 
		if (q5 == 'A' || q5 == 'a') {
			printf("\nCongratulations you got it correct !\n\n");
			sleep(2); 
		} else {
			printf("\nThat is incorrect !\n\n"); 
			sleep(2); 
		}
		system("clear"); //unix/linux
	}

	if (q == 6) {
		question6 = fopen("question6.txt", "r"); 
		if (question6) {
			while(fgets(buffer, 256, question6)) {
				fputs(buffer, stdout); 
			}
			fclose(question6); 
		} else {
			/* Provide error diagnostic. */
			fprintf(stderr, "Could not open that question."); 
			perror(0); 
			errno = 0; 
		}

		question_prompt(); 
		scanf(" %c", &q6); 
		if (q6 == 'A' || q6 == 'a') {
			printf("\nCongratulations you got it correct !\n\n");
			sleep(2); 
		} else {
			printf("\nThat is incorrect !\n\n"); 
			sleep(2); 
		}
		system("clear"); //unix/linux
	}

	if (q == 7) {
		question7 = fopen("question7.txt", "r"); 
		if (question7) {
			while(fgets(buffer, 256, question7)) {
				fputs(buffer, stdout); 
			}
			fclose(question7); 
		} else {
			/* Provide error diagnostic. */
			fprintf(stderr, "Could not open that question."); 
			perror(0); 
			errno = 0; 
		}

		question_prompt(); 
		scanf(" %c", &q7); 
		if (q7 == 'A' || q7 == 'a') {
			printf("\nCongratulations you got it correct !\n\n");
			sleep(2); 
		} else {
			printf("\nThat is incorrect !\n\n"); 
			sleep(2); 
		}
		system("clear"); //unix/linux
	}

	if (q == 8) {
		question8 = fopen("question8.txt", "r"); 
		if (question8) {
			while(fgets(buffer, 256, question8)) {
				fputs(buffer, stdout); 
			}
			fclose(question8); 
		} else {
			/* Provide error diagnostic. */
			fprintf(stderr, "Could not open that question."); 
			perror(0); 
			errno = 0; 
		}

		question_prompt(); 
		scanf(" %c", &q8); 
		if (q8 == 'D' || q8 == 'd') {
			printf("\nCongratulations you got it correct !\n\n");
			sleep(2); 
		} else {
			printf("\nThat is incorrect !\n\n"); 
			sleep(2); 
		}
		system("clear"); //unix/linux
	}

	if (q == 9) {
		question9 = fopen("question9.txt", "r"); 
		if (question9) {
			while(fgets(buffer, 256, question9)) {
				fputs(buffer, stdout); 
			}
			fclose(question9); 
		} else {
			/* Provide error diagnostic. */
			fprintf(stderr, "Could not open that question."); 
			perror(0); 
			errno = 0; 
		}

		question_prompt(); 
		scanf(" %c", &q9); 
		if (q9 == 'A' || q9 == 'a') {
			printf("\nCongratulations you got it correct !\n\n");
			sleep(2); 
		} else {
			printf("\nThat is incorrect !\n\n"); 
			sleep(2); 
		}
		system("clear"); //unix/linux
	}

	if (q == 10) {
		question10 = fopen("question10.txt", "r"); 
		if (question10) {
			while(fgets(buffer, 256, question10)) {
				fputs(buffer, stdout); 
			}
			fclose(question1); 
		} else {
			/* Provide error diagnostic. */
			fprintf(stderr, "Could not open that question."); 
			perror(0); 
			errno = 0; 
		}

		question_prompt(); 
		scanf(" %c", &q10); 
		if (q10 == 'B' || q10 == 'b') {
			printf("\nCongratulations you got it correct !\n\n");
			sleep(2); 
		} else {
			printf("\nThat is incorrect !\n\n"); 
			sleep(2); 
		}	
		system("clear"); //unix/linux
	}
}
 
int main(int argc, char** argv) {
	  
	initialise_quiz();
	for (int count = 1; count < 11; count++) {
		display_question(count);  
	}
}

